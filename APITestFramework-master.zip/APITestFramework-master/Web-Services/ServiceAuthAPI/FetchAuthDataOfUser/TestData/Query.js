var queryforAuthData =``; 

module.exports.generateDynamicQueryforAuthData = function(){

  
}

